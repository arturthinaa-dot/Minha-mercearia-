# Minha Mercearia — Android

Versão Android do aplicativo **Minha Mercearia**, com a área de Poupança e várias metas.

## Ícone
Esta versão usa o novo ícone com **carrinho de compras**.

## Gerar APK pelo GitHub
Envie este arquivo ZIP para o repositório GitHub e substitua o ZIP anterior. Depois execute o workflow `Build-app.yml` em Actions.

O APK será publicado como artefato `MinhaMercearia-APK`.
