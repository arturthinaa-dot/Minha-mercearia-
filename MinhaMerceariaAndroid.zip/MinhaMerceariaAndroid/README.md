# Minha Mercearia — Android

Projeto Android que empacota a aplicação `index.html` como aplicação offline.

## Gerar o APK
1. Abra esta pasta no Android Studio.
2. Espere o Gradle sincronizar.
3. Escolha **Build > Build APK(s)**.
4. O APK será criado em `app/build/outputs/apk/debug/app-debug.apk`.

A aplicação não precisa de internet para funcionar depois de instalada. Os dados são guardados no armazenamento local do WebView.
